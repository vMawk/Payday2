-- EXTEND INVENTORY SLOTS
-- Author: Baddog-11

-- For Masks
tweak_data.gui.MASK_ROWS_PER_PAGE		= 6		-- Default Value : 4
tweak_data.gui.MASK_COLUMNS_PER_PAGE	= 6		-- Default Value : 4
tweak_data.gui.MAX_MASK_PAGES			= 12	-- Default Value : 5
tweak_data.gui.MAX_MASK_ROWS			= 1337	-- Default Value : 3
-- For Weapons
tweak_data.gui.WEAPON_ROWS_PER_PAGE		= 6		-- Default Value : 4
tweak_data.gui.WEAPON_COLUMNS_PER_PAGE	= 6		-- Default Value : 4
tweak_data.gui.MAX_WEAPON_PAGES			= 12	-- Default Value : 5
tweak_data.gui.MAX_WEAPON_ROWS			= 1337	-- Default Value : 3