-- Purpose: Hides your Mods
-- Author: Baddog-11
function MenuCallbackHandler:build_mods_list()
	return {}
end