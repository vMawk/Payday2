local backuper = backuper

backuper:backup('CrimeSpreeManager.randomization_cost')
function CrimeSpreeManager.randomization_cost()
	return 0
end

backuper:backup('CrimeSpreeManager.get_start_cost')
function CrimeSpreeManager.get_start_cost()
	return 0
end

backuper:backup('CrimeSpreeManager.get_continue_cost')
function CrimeSpreeManager.get_continue_cost()
	return 0
end