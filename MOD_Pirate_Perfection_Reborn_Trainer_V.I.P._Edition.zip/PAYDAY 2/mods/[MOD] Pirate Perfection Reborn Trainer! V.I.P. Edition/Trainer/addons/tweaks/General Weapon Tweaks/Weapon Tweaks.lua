-- WEAPON TWEAKS
	for _,stats in pairs(tweak_data.weapon) do
		if ( stats ) then
		--	stats.damage			= 210
		--	stats.spread			= 26
		--	stats.recoil			= 26
		--	stats.spread_moving		= 26
		--	stats.zoom				= 10
			--stats.concealment		= 30
		--	stats.suppression		= 20
		--	stats.alert_size		= 20	--Comment this out if you don't want every part to act like a silencer.
		--	stats.extra_ammo		= 50
			--stats.total_ammo_mod	= 20
		--	stats.value				= 10
		--	stats.reload			= 21
		--	stats.fire_rate			= 00
		end
	end