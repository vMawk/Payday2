tweak_data.blackmarket.projectiles.chico_injector.no_cheat_count = true
tweak_data.blackmarket.projectiles.chico_injector.max_amount = 50
tweak_data.blackmarket.projectiles.chico_injector.base_cooldown = 5

tweak_data.blackmarket.projectiles.frag_com.no_cheat_count = true
tweak_data.blackmarket.projectiles.frag_com.max_amount = 50

tweak_data.blackmarket.projectiles.wpn_prj_ace.no_cheat_count = true
tweak_data.blackmarket.projectiles.wpn_prj_ace.max_amount = 50

tweak_data.blackmarket.projectiles.concussion.no_cheat_count = true
tweak_data.blackmarket.projectiles.concussion.max_amount = 50

tweak_data.blackmarket.projectiles.frag.no_cheat_count = true
tweak_data.blackmarket.projectiles.frag.max_amount = 50

tweak_data.blackmarket.projectiles.molotov.no_cheat_count = true
tweak_data.blackmarket.projectiles.molotov.max_amount = 50

tweak_data.blackmarket.projectiles.dynamite.no_cheat_count = true
tweak_data.blackmarket.projectiles.dynamite.max_amount = 50

tweak_data.blackmarket.projectiles.wpn_prj_four.no_cheat_count = true
tweak_data.blackmarket.projectiles.wpn_prj_four.max_amount = 50

tweak_data.blackmarket.projectiles.wpn_prj_jav.no_cheat_count = true
tweak_data.blackmarket.projectiles.wpn_prj_jav.max_amount = 50

tweak_data.blackmarket.projectiles.wpn_prj_hur.no_cheat_count = true
tweak_data.blackmarket.projectiles.wpn_prj_hur.max_amount = 50

tweak_data.blackmarket.projectiles.wpn_prj_target.no_cheat_count = true
tweak_data.blackmarket.projectiles.wpn_prj_target.max_amount = 50

tweak_data.blackmarket.projectiles.launcher_m203.time_cheat = 0.01
tweak_data.blackmarket.projectiles.launcher_incendiary_arbiter.time_cheat = 0.01