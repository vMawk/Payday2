Place your lua plugins for Pirate Perfection Reborn here.
You can access them all from the speicific menu.